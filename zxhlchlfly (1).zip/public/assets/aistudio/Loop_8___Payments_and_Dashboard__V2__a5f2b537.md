# Loop 8 — Payments and Dashboard (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, on top of finished Loops 1 to 7 · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

This loop continues one app. With this document you receive the **App Map** and the **current app** (design and code) as the last loop left it.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- Each item below is marked **EXISTING** (leave alone), **EXTEND** (change in place, exactly as listed) or **NEW** (create).
- If you cannot find an existing screen or component, stop and ask me. Do not recreate it.

**EXISTING (leave alone):** every Officer and Airman screen, Customers, Drafts, print pages, Settings, the Workers list, and the grid on the Worker page.

**EXTEND (change in place):**
- **Staff Summary:** add the **Total Received** and **Total Due** cards, the **Status** filter, the columns **Received**, **Due**, **Status**, and the buttons **History** and **Pay**. Do not create a second Staff Summary.
- **Worker page:** add **Received** and **Due** to the footer. Add the payments to the worker statement.
- **Navigation:** add **Dashboard** before Settings (after Staff Summary).

**NEW:** the worker **Pay** popup, the worker **History** screen, and the **Dashboard**. The Dashboard reuses the existing summary cards, tabs, tables and side panels.

## 1. Purpose and rules for the builder

Loop 8 finishes the staff accounts and adds the Dashboard. First, it adds **worker payments** to Staff Summary: the owner records that he paid a worker, and the app shows Received, Due and Status. Second, it adds the **Dashboard**, which shows orders, money, staff figures and profit by period.

A worker payment is **only a record inside the app**. The app never moves money. There is no bKash, no gateway and no online payment, ever.

**Rules**

- Build only what is written here, on top of Loops 1 to 7. Do not change Officer, Airman or Loop 7 behaviour, except where this document says so.
- If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- There is **no login**. Every user can add, edit and delete.
- Money is in taka (৳). Never write the word "optional" anywhere in the screen text.
- Every screen has loading placeholders and a friendly empty message.

## 2. What is new in this loop

1. **Pay** (a payment record), **Received**, **Due** and **Status** for each worker.
2. **History** of months and payments per worker.
3. Two more cards and a status filter on **Staff Summary**.
4. The **Dashboard** screen.

## 3. What changes from earlier loops

- **Staff Summary** gets the columns **Received**, **Due**, **Status** and the buttons **History** and **Pay**, two more cards (**Total Received**, **Total Due**), and a **Status** filter.
- The **worker page** footer gets **Received** and **Due**. The worker **PDF** statement lists that month's payments.
- Navigation gets a **Dashboard** link, after Staff Summary.
- Deleting a worker is blocked if he has payments (already blocked for any record).
- Nothing else changes.

## 4. Worker payments

### 4.1 Payments belong to a month

A payment has: **For Month**, **Amount**, **Date** and a **Note**. It is recorded against one month's hishab. For a month:

- **Net Payable** = Total Amount − Khoroch (from Loop 7).
- **Received** = sum of payments for that month.
- **Due** = Net Payable − Received.
- **Status:** **Paid** (green) when Due is 0 or less and Net Payable is above 0. **Partial** (orange) when Received is above 0 and Due is above 0. **Unpaid** (red) when nothing is received and Net Payable is above 0. A worker with Net Payable 0 and Received 0 shows "—".
- Due above 0 is shown in red.

### 4.2 Where Received, Due, Status and Pay work

These columns and the Pay button work when the Staff Summary period is a **whole month** (**This Month**, **Last Month**, **Pick Month**) or **All Time**. For **Today**, **This Week** and **Last Week** they are hidden, because a payment belongs to a month. For **All Time**, Received and Due are the sums over all months.

### 4.3 The Pay popup

**Pay** opens a small dialog titled "Record payment" with the worker's name and the month.

- It shows **Net Payable**, **Received** and **Due** for that month.
- Boxes: **Amount** (taka), **Date** (today by default), **Note**.
- A **Pay Full** button that fills Amount with the Due. The owner can also type any amount.
- Buttons: **Cancel** and **Save Payment**.
- Rules: Amount must be above 0. An Amount above the Due is refused with "Amount is more than the Due of ৳X." When the Due is 0 or less, Pay is disabled and the row shows Paid.
- The dialog says in a short line that it records a payment already made and does not send money.
- After saving, the row's Received, Due and Status and the cards update at once.
- For **All Time**, Pay asks for the **month** first (a month picker, defaulting to the oldest month with a Due) and then works as above.

### 4.4 History

**History** opens a screen for that worker (back arrow to Staff Summary):

- **Months:** a table of every month that has work, Khoroch or payments: Month, Total Amount, Khoroch, Net Payable, Received, Due, Status. Tapping a month opens the worker page for it.
- **Payments:** a list of all payment records, newest first: Date, For Month, Amount, Note, with **Edit** and **Delete** icons.
- **Edit payment:** change Amount, Date, For Month and Note. The same rule applies: the total received for that month cannot go above its Net Payable.
- **Delete payment:** asks for confirmation. The month's Received and Due update at once.
- An empty history shows a friendly message.

### 4.5 Staff Summary additions

- Cards, in this order: Total Staff, Total Amount, Total Khoroch, Total Payable, **Total Received**, **Total Due** (hidden for Today and weeks).
- Table columns become: #, Staff Name, Works, Total Amount, Khoroch, Net Payable, **Received**, **Due**, **Status**, Details, **History**, **Pay**.
- A **Status** filter: All Status, Unpaid, Partial, Paid.
- **CSV** includes the new columns.

## 5. Dashboard

The Dashboard is automatic and read-only. It uses the existing definitions: **Sales** = Officer order totals after discount, counted on the order date. **Collection** = advances (counted on the order date) plus Pay amounts (counted on the Pay date). **Due** = money still unpaid by customers. Airman orders have no money.

### 5.1 Period

A switch at the top: **Today**, **This Week**, **This Month** (default), **This Year**, **All Time**.

- **This Week** runs Saturday to Friday.
- **This Year** is the calendar year. When it is chosen, a **Year** dropdown appears with every year that has data.
- Every card, chart and table below follows the period, except where noted.

### 5.2 Orders and money (Officer)

Four cards: **Orders**, **Sales**, **Collection**, **Due**. Due is the total owed by customers on Officer orders at present.

### 5.3 Staff

Cards: **Staff Work** (total earned by workers in the period), **Khoroch**, **Payable** (Staff Work − Khoroch), **Paid** (payments **dated** in the period), **Due** (the total still owed to workers at present, all months).

### 5.4 Profit

One card: **Profit** = **Sales** − **Staff Work**. Green when above 0, red when below. Khoroch is not counted separately, because it is money already included in what the workers earned.

### 5.5 Quick numbers (not affected by the period)

**Total Customers** (Officer and Airman), **Upcoming Deliveries**, **Delivered Orders**, **Total Staff**, and **Airman Orders** (count of Airman orders placed in the period).

### 5.6 Charts

- **Monthly chart:** a bar chart by month for the selected year (or the current year). A three-way switch: **Orders & Sales**, **Profit** (Sales, Staff Work, Profit), **Payments** (Collection and Staff Paid).
- **Order status:** a donut of Officer orders: Pending, Cutting Slip – Done, Delivered.
- **Daily chart:** Orders and Sales for each day of the period (the last 7 days when the period is Today or All Time).

### 5.7 Recent Orders

A table of the 10 newest Officer orders: order number, name, status, total, due. Tapping a row opens the order.

### 5.8 Tapping a number

Tapping a card shows the details behind it, in a panel:

- **Orders** and **Sales:** the orders in the period.
- **Collection:** the advances and Pay amounts with their dates.
- **Due:** the Delivered orders with Due above 0.
- **Staff Work, Khoroch, Payable:** a list of workers with their figures for the period.
- **Paid:** the worker payments in the period.
- **Due (staff):** the workers with Due above 0.
- **Profit:** the two figures, Sales and Staff Work, and their difference.

Each panel has a friendly message when empty.

## 6. User flows

**A. Pay a worker.** Staff Summary → Last Month → Pay on Rashid → Pay Full → Save Payment → Received rises, Due 0, Status Paid.

**B. Part payment.** Pay → type 3000 → Save → Status Partial → later Pay Full for the rest.

**C. Fix a mistake.** History → Edit a payment → change the amount → Save.

**D. See what is owed.** Staff Summary → Status filter Unpaid → see the workers.

**E. Month check.** Dashboard → This Month → read Sales, Staff Work and Profit.

**F. Yearly figures.** Dashboard → This Year → pick the year → read Orders, Sales and Profit, and the monthly chart.

## 7. Not in this loop (do not build)

Real payments or online payment of any kind, payment methods, receipts, reminders and notifications, Bangla language switch and Bangla digits, dark mode, install as an app, backup, login and security (a later loop), salary, percentage pay, attendance, any Export button outside the staff screens, and any figure not listed here.

## 8. Choices I made, to confirm

1. Payments belong to a **month** (For Month), so months can be Paid, Partial or Unpaid separately.
2. Received, Due, Status and Pay show only for whole-month periods and All Time.
3. Partial payments **are** allowed for workers (unlike customers). Overpaying a month is refused.
4. Profit = Sales − Staff Work. Khoroch is not subtracted again.
5. Dashboard Due (customers and staff) is the amount owed **at present**, not only inside the period.
6. Paid on the Dashboard is counted on the payment **Date**.
7. This Year means the calendar year, not the Running Year.
8. The order-status donut shows Pending, Cutting Slip – Done and Delivered, not "Due" as written in the PRD.
9. Workers with Net Payable 0 and nothing received show "—" for Status.
10. The Dashboard is named **Dashboard** (the reference calls it Dashboard Report).
11. The Dashboard Airman section is a count only.

## 9. Done checklist (test in this order)

1. Staff Summary on a whole-month period shows Received, Due and Status. On Today, This Week and Last Week they are hidden.
2. Pay on a worker with a Net Payable: the dialog shows the right Net Payable, Received and Due. Pay Full fills the Due. Save: Received rises, Due 0, Status Paid, and the cards update.
3. Type a part amount: Status Partial and the Due is correct. Type more than the Due: refused with the message. Type 0: refused.
4. Pay is disabled when the Due is 0.
5. Pay on All Time asks for a month first.
6. History: months table and payment list are right. Edit a payment and the month's Received and Due change. Delete a payment with confirmation: the same.
7. The Status filter works (Unpaid, Partial, Paid). CSV has the new columns.
8. The worker page footer shows Received and Due. The PDF lists the payments.
9. A worker with payments cannot be deleted.
10. Dashboard: change the period through all five options. The four order cards, the staff cards and Profit change. Profit = Sales − Staff Work.
11. Collection counts advances on the order date and Pay amounts on the Pay date. Staff Paid counts payments on their Date.
12. The Year dropdown appears under This Year and changes the figures. The monthly chart switch shows all three views.
13. Tap each card: the right details show. Empty periods show friendly messages.
14. Delete an order, a worker payment and a worker row: the Dashboard numbers shrink at once.
15. Recent Orders shows the 10 newest Officer orders and opens an order when tapped.
16. Officer, Airman and Loop 7 screens behave as before. There is no real payment or gateway anywhere.
17. The word "optional" appears nowhere.
