# Loop 3 — Printing: Cutting Slip and Invoice (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, on top of finished Loops 1 and 2 · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

This loop continues one app. With this document you receive the **App Map** and the **current app** (design and code) as the last loop left it.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- Each item below is marked **EXISTING** (leave alone), **EXTEND** (change in place, exactly as listed) or **NEW** (create).
- If you cannot find an existing screen or component, stop and ask me. Do not recreate it.

**EXISTING (leave alone):** navigation, Orders screen layout (cards, tabs, summary cards, search, sort), status dropdown, Pay, Delivery screen, Order Details content, Settings Items, Discount, Ribbon and Upcoming days.

**EXTEND (change in place):**
- **Order card:** add two icons, Cutting Slip and Invoice.
- **Order Details:** add two bottom buttons, Print Slip and Invoice, beside Edit Order.
- **New / Edit Order form:** add two buttons, Print Invoice and Cutting Slip, beside Save.
- **Settings:** add the **Invoice template** block and the **Print paper size** block.

**NEW:** the **Cutting Slip** page and the **Invoice** page (a print preview page with Print, Back and a link to the other paper).

## 1. Purpose and rules for the builder

Loop 3 lets the owner print two papers for every Officer order: the **Cutting Slip** (goes with the cloth to the tailor) and the **Invoice** (goes to the customer). When both print correctly from every place a print button appears, the loop is done.

**Rules**

- Build only what is written here, on top of Loops 1 and 2. Do not change earlier behaviour except where section 3 says so.
- If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- Officer orders only. Airman slips come in a later loop.
- Use the browser’s normal print. No special printer software.
- Never write the word "optional" anywhere in the screen text.

## 2. What is new in this loop

1. A **Cutting Slip** page and an **Invoice** page for any saved order.
2. Print buttons in four places (section 5).
3. Settings: **Invoice template** and **Print paper size**.

## 3. What changes from earlier loops

- The New / Edit Order form gets two buttons beside Save: **Print Invoice** and **Cutting Slip**.
- The order card gets two icons: **Cutting Slip** and **Invoice**.
- Order Details gets two bottom buttons: **Print Slip** and **Invoice**, beside Edit Order.
- Settings gets two new blocks.

## 4. The two papers

### 4.1 Cutting Slip (for the tailor)

Shows, from top to bottom:

- Shop name and the title "Cutting Slip".
- Order number, order date, **delivery date**, ribbon.
- Customer name and BD number.
- Items list: item name and quantity. **No prices and no money anywhere on this paper.**
- **Shirt** measurements: only the fields that were filled in (Length, Chest, Belly, Hip, Shoulder, Sleeve, Collar, Front, Back).
- **Pant** measurements: only the fields that were filled in (Length, Waist, Hip, High, Thai, Leg Open).
- **Hand Written Notes** and **Extra Notes** for shirt and for pant, when filled in.
- If an order somehow has no items, show: "No cutting slip found for this category in the selected order."

### 4.2 Invoice (for the customer)

Shows, from top to bottom:

- Shop logo, shop name and the title "Invoice".
- Order number, order date, delivery date.
- Customer name, BD number, phone (when there is one).
- Items table: item name, quantity, price, line total.
- Money: Total, Discount, Advance, Received later (the Pay amounts, only if there are any), and **Due**.
- The terms text from Settings, at the bottom.
- No measurements and no status on the invoice.

### 4.3 Layout rules for both

- Plain black on white, clear on a black-and-white printer.
- Fits one page for a normal order. A very long item list may continue on a second page, with the money block at the end of the last page.
- The app menu, buttons and navigation never appear in the printout.
- The order number printed is the number at the time of printing. If orders are deleted later, numbers can shift (see Loop 1).

## 5. Where the print buttons are

1. **Order card:** a Cutting Slip icon and an Invoice icon.
2. **Order Details:** bottom buttons **Print Slip** and **Invoice**.
3. **New / Edit Order form:** buttons **Print Invoice** and **Cutting Slip** beside Save.
   - On the form, these buttons **save the order first** (all normal saving rules apply, including the missing-fields message), then open the paper. On a new order this creates the order and assigns its number.
4. **Print page itself:** each paper opens on its own page showing a preview, with a **Print** button, a **Back** button, and a link to switch to the other paper for the same order.

Tapping **Print** opens the browser’s print dialog for the paper size set in Settings.

## 6. Settings additions

### 6.1 Invoice template

- **Shop name** (text).
- **Logo** (upload one image; shown on the invoice; a Remove button).
- **Terms** (a text box; for example payment and delivery notes).
- A small live preview of the invoice header, so the owner sees changes.

### 6.2 Print paper size

- Two dropdowns: **Invoice paper size** and **Cutting slip paper size**.
- Choices: **A4** (default) and **A5**. More sizes can be added later when the owner decides.

## 7. Data additions

- **Settings:** shop name, logo image, terms text, invoice paper size, cutting slip paper size.
- Nothing new is stored on orders. Papers are built from the saved order each time.

## 8. User flows

**A. Print right after taking an order.** New Order → fill the form → tap Cutting Slip → the order saves → slip preview opens → Print → back to the order.

**B. Print the invoice at delivery.** Orders → tap the Invoice icon on the card → preview → Print → hand it over → set Delivered → Pay if needed.

**C. Reprint after an edit.** Edit Order → change items or measurements → Update Order → Print Slip. The paper shows the new details.

**D. Set up the shop paper.** Settings → enter shop name, upload the logo, write the terms → check the preview → print an invoice and see the same header.

**E. Change paper size.** Settings → set Invoice paper size to A5 → print an invoice → the print dialog uses A5.

**F. Order with unsaved changes.** Edit Order → change the delivery date → tap Print Invoice without saving → the order updates first, then the invoice shows the new date.

## 9. Not in this loop (do not build)

Airman slips and IV-Numbers on papers, sending papers by message or email, saving as a file inside the app, drafts, Customers pages, Dashboard, Bangla, dark mode, install as an app, thermal receipt sizes, login, Branch, Export, staff pages, notifications.

## 10. Choices I made, to confirm

1. Only **A4 and A5** are offered. If you meant a different size by "4.3", tell me the size and I will change it.
2. The two papers have **separate** paper size settings.
3. Print buttons on the form **save first**, so a printed paper always matches a saved order.
4. The slip prints only measurement fields that were filled in, so it stays short.
5. The invoice shows no measurements and no status.

## 11. Done checklist (test in this order)

1. Settings: enter a shop name, upload a logo, write terms. The preview shows them.
2. Open an order and tap **Invoice**. The invoice shows logo, shop name, order number, dates, customer, items with prices, Total, Discount, Advance and Due, and the terms.
3. Tap **Print Slip** on the same order. The slip shows the customer, ribbon, delivery date, items with quantity and **no prices**, filled measurements only, and the notes.
4. Pay an order (Loop 2), then open its invoice: "Received later" shows the amount and Due is 0.
5. On the Orders list, the Cutting Slip icon and Invoice icon open the right paper for that card.
6. On a brand-new order form, tap **Cutting Slip** with nothing filled in: nothing is saved and the missing-fields message shows.
7. Fill the form and tap **Print Invoice**: the order is saved with the next number, and the invoice opens.
8. Edit an order, change the delivery date, tap **Cutting Slip** without saving: the order updates first and the slip shows the new date.
9. On the print page, **Print** opens the print dialog with no menu or buttons in the preview, and **Back** returns to where you came from.
10. Set Invoice paper size to A5: the invoice prints on A5 while the slip is still A4.
11. An order with many items still prints cleanly, with the money block on the last page.
12. The word "optional" appears nowhere.
