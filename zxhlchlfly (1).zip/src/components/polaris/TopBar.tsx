import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import {
  Scissors,
  Search,
  Bell,
  Menu,
  X,
  Settings,
} from 'lucide-react';

interface TopBarProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
  onOpenSearch: () => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  onNavigate,
  onOpenSearch,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const { state } = useApp();

  // Calculate urgent/attention count for notification bell
  const upcomingCount = state.officerOrders.filter((o) => {
    if (o.status === 'Delivered') return false;
    if (!o.deliveryDate) return false;
    const diff = (new Date(o.deliveryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
    return diff >= 0 && diff <= (state.settings.upcomingDeliveryDays || 3);
  }).length;

  const dueCount = state.officerOrders.filter(
    (o) => o.status === 'Delivered' && o.due > 0
  ).length;

  const alertCount = upcomingCount + dueCount;

  return (
    <header
      className="h-14 bg-[#1A1A1A] text-white flex items-center justify-between px-3 sm:px-5 sticky top-0 z-40 select-none print:hidden border-b border-[#2A2A2A]"
      style={{ height: 'var(--topbar-h)' }}
    >
      {/* Left: Brand Lockup & Mobile Toggle */}
      <div className="flex items-center space-x-3 min-w-[200px]">
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-1.5 text-gray-300 hover:text-white rounded-md hover:bg-[#303030] focus:outline-none focus:ring-1 focus:ring-white"
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        <div
          onClick={() => onNavigate('orders')}
          className="flex items-center space-x-2.5 cursor-pointer group"
          title="Raymond - Tailoring Management"
        >
          <div className="w-7 h-7 rounded-md bg-[#303030] border border-[#404040] flex items-center justify-center text-white shadow-xs group-hover:border-gray-400 transition-colors">
            <Scissors className="w-4 h-4 transform -rotate-45" />
          </div>
          <span className="font-bold text-white text-base tracking-tight leading-none">
            Raymond
          </span>
        </div>
      </div>

      {/* Center: Global Search Bar (Max 650px, Centered) */}
      <div className="flex-1 max-w-[650px] mx-2 sm:mx-6">
        <button
          onClick={onOpenSearch}
          className="w-full h-9 rounded-2xl bg-[#303030] hover:bg-[#3A3A3A] transition-colors flex items-center justify-between px-3 text-[#B5B5B5] border border-transparent focus:outline-none focus:border-[#555] text-xs shadow-xs cursor-pointer group"
          aria-label="Global search (Cmd + K)"
        >
          <div className="flex items-center space-x-2 truncate">
            <Search className="w-4 h-4 text-[#8A8A8A] group-hover:text-gray-300" />
            <span className="truncate">Search orders, customers, workers...</span>
          </div>
          <div className="flex items-center space-x-1 shrink-0 ml-2">
            <kbd className="min-w-[20px] h-5 px-1 rounded bg-[#3A3A3A] group-hover:bg-[#444] text-[#B5B5B5] text-[11px] font-medium flex items-center justify-center border border-[#4A4A4A]">
              ⌘
            </kbd>
            <kbd className="min-w-[20px] h-5 px-1 rounded bg-[#3A3A3A] group-hover:bg-[#444] text-[#B5B5B5] text-[11px] font-medium flex items-center justify-center border border-[#4A4A4A]">
              K
            </kbd>
          </div>
        </button>
      </div>

      {/* Right: Actions, Notifications Bell & Workspace Switcher */}
      <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
        {/* Quick New Order Action */}
        <button
          onClick={() => onNavigate('new-officer-order')}
          className="hidden sm:inline-flex items-center space-x-1.5 h-7 px-2.5 rounded-lg bg-[#303030] hover:bg-[#3A3A3A] text-white text-xs font-medium border border-[#444] transition-colors"
          title="New Officer Order"
        >
          <span>New Order</span>
        </button>

        {/* Notifications Bell */}
        <button
          onClick={() => onNavigate('delivery')}
          className="relative p-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-[#303030] transition-colors focus:outline-none focus:ring-1 focus:ring-white"
          title={alertCount > 0 ? `${alertCount} orders requiring attention` : 'Notifications'}
          aria-label="Notifications"
        >
          <Bell className="w-4 h-4" />
          {alertCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#D72C35] text-white text-[10px] font-bold flex items-center justify-center shadow-xs">
              {alertCount > 9 ? '9+' : alertCount}
            </span>
          )}
        </button>

        {/* Settings Action (Replaces duplicate shop avatar to avoid two logos) */}
        <button
          onClick={() => onNavigate('settings')}
          className="p-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-[#303030] transition-colors focus:outline-none focus:ring-1 focus:ring-white"
          title="Store Settings"
          aria-label="Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
