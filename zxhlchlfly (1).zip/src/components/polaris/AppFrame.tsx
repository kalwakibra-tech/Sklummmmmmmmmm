import React, { useState } from 'react';
import { ScreenName } from '../Navbar.tsx';
import { TopBar } from './TopBar.tsx';
import { Sidebar } from './Sidebar.tsx';
import { GlobalSearchModal } from './GlobalSearchModal.tsx';
import { OfflineIndicator } from '../OfflineIndicator.tsx';
import { ClipboardList, Plane, Truck, LayoutDashboard, Menu, Sparkles } from 'lucide-react';

interface AppFrameProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  children: React.ReactNode;
}

export const AppFrame: React.FC<AppFrameProps> = ({
  currentScreen,
  onNavigate,
  children,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);

  const isOfficerActive =
    currentScreen === 'orders' ||
    currentScreen === 'new-officer-order' ||
    currentScreen === 'edit-officer-order' ||
    currentScreen === 'order-details';

  const isAirmanActive =
    currentScreen === 'airman-orders' ||
    currentScreen === 'new-airman-order' ||
    currentScreen === 'edit-airman-order';

  const isDashboardActive = currentScreen === 'dashboard';

  return (
    <div className="min-h-screen bg-[#1A1A1A] flex flex-col font-sans selection:bg-[#303030] selection:text-white pb-16 lg:pb-0">
      {/* Layer 0: Chrome TopBar (56px, #1A1A1A) */}
      <TopBar
        onNavigate={onNavigate}
        onOpenSearch={() => setSearchModalOpen(true)}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      {/* Layer 1 & 2: Rail & Canvas with 12px Top-Left Radius */}
      <div className="flex-1 flex bg-[#F1F1F1] rounded-tl-xl overflow-hidden min-h-0">
        {/* Layer 1: Rail Sidebar (240px, #EBEBEB) */}
        <Sidebar
          currentScreen={currentScreen}
          onNavigate={onNavigate}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />

        {/* Layer 2: Main Canvas (#F1F1F1) */}
        <main className="flex-1 overflow-y-auto min-w-0 bg-[#F1F1F1]">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Thumb Navigation Bar (< 1024px) */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-14 bg-white/95 backdrop-blur-md border-t border-[#E3E3E3] flex items-center justify-around px-1 shadow-md"
        aria-label="Mobile Navigation"
      >
        <button
          onClick={() => onNavigate('orders')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isOfficerActive ? 'text-[#1A1A1A] font-semibold' : 'text-[#616161] hover:text-[#1A1A1A]'
          }`}
        >
          <ClipboardList className={`w-5 h-5 ${isOfficerActive ? 'stroke-[2.4] text-[#1A1A1A]' : 'stroke-[1.6]'}`} />
          <span className="text-[10px] mt-0.5 tracking-tight">Officers</span>
        </button>

        <button
          onClick={() => onNavigate('airman-orders')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isAirmanActive ? 'text-[#1A1A1A] font-semibold' : 'text-[#616161] hover:text-[#1A1A1A]'
          }`}
        >
          <Plane className={`w-5 h-5 ${isAirmanActive ? 'stroke-[2.4] text-[#1A1A1A]' : 'stroke-[1.6]'}`} />
          <span className="text-[10px] mt-0.5 tracking-tight">Airman</span>
        </button>

        <button
          onClick={() => onNavigate('delivery')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentScreen === 'delivery' ? 'text-[#1A1A1A] font-semibold' : 'text-[#616161] hover:text-[#1A1A1A]'
          }`}
        >
          <Truck className={`w-5 h-5 ${currentScreen === 'delivery' ? 'stroke-[2.4] text-[#1A1A1A]' : 'stroke-[1.6]'}`} />
          <span className="text-[10px] mt-0.5 tracking-tight">Delivery</span>
        </button>

        <button
          onClick={() => onNavigate('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isDashboardActive ? 'text-[#1A1A1A] font-semibold' : 'text-[#616161] hover:text-[#1A1A1A]'
          }`}
        >
          <LayoutDashboard className={`w-5 h-5 ${isDashboardActive ? 'stroke-[2.4] text-[#1A1A1A]' : 'stroke-[1.6]'}`} />
          <span className="text-[10px] mt-0.5 tracking-tight">Dashboard</span>
        </button>

        <button
          onClick={() => setMobileMenuOpen(true)}
          className="flex flex-col items-center justify-center flex-1 py-1 text-[#616161] hover:text-[#1A1A1A] transition-colors"
        >
          <Menu className="w-5 h-5 stroke-[1.6]" />
          <span className="text-[10px] mt-0.5 tracking-tight">Menu</span>
        </button>
      </nav>

      {/* Polaris Global Search Modal (⌘K) */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onNavigate={onNavigate}
      />

      {/* Offline Status Pill */}
      <OfflineIndicator />
    </div>
  );
};

