import React from 'react';

export type BadgeTone = 'success' | 'info' | 'neutral' | 'critical' | 'warning';

interface PolarisBadgeProps {
  children: React.ReactNode;
  tone?: BadgeTone;
  interactive?: boolean;
  onClick?: () => void;
  className?: string;
}

export const PolarisBadge: React.FC<PolarisBadgeProps> = ({
  children,
  tone = 'neutral',
  interactive = false,
  onClick,
  className = '',
}) => {
  const toneStyles: Record<BadgeTone, string> = {
    success: 'bg-[#AFFEBF] text-[#0C5132]',
    info: 'bg-[#C4E4F9] text-[#00527C]',
    neutral: 'bg-[#E3E3E3] text-[#4A4A4A]',
    critical: 'bg-[#FEE9E8] text-[#8E0B21]',
    warning: 'bg-[#FFEA8A] text-[#5E4200]',
  };

  return (
    <span
      onClick={interactive ? onClick : undefined}
      className={`inline-flex items-center h-5 px-2 rounded-lg text-[12px] leading-4 font-[450] whitespace-nowrap transition-colors ${
        toneStyles[tone]
      } ${interactive ? 'cursor-pointer hover:opacity-90 active:scale-95' : ''} ${className}`}
      style={{ borderRadius: 'var(--radius-sm)' }}
    >
      {children}
    </span>
  );
};
