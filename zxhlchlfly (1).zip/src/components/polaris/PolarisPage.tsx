import React from 'react';
import { ArrowLeft } from 'lucide-react';

export interface ActionItem {
  label: string;
  onClick: () => void;
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface PolarisPageProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  backAction?: () => void;
  primaryAction?: ActionItem;
  secondaryActions?: ActionItem[];
  children: React.ReactNode;
  fullWidth?: boolean;
}

export const PolarisPage: React.FC<PolarisPageProps> = ({
  title,
  subtitle,
  badge,
  backAction,
  primaryAction,
  secondaryActions = [],
  children,
  fullWidth = false,
}) => {
  return (
    <div className="min-h-full bg-[#F1F1F1] text-[#303030] pb-16">
      {/* Container with Polaris 24px padding */}
      <div className={`mx-auto px-4 sm:px-6 py-6 space-y-4 ${fullWidth ? 'max-w-7xl' : 'max-w-6xl'}`}>
        {/* Polaris Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          {/* Left: Back button + Title + Badge */}
          <div className="flex items-center space-x-2.5">
            {backAction && (
              <button
                onClick={backAction}
                className="w-7 h-7 rounded-lg flex items-center justify-center text-[#616161] hover:text-[#1A1A1A] hover:bg-[#E3E3E3] transition-colors shrink-0"
                aria-label="Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <div className="flex items-center space-x-2.5">
                <h1 className="text-[20px] leading-7 font-[650] text-[#1A1A1A] tracking-tight">
                  {title}
                </h1>
                {badge && <div className="shrink-0">{badge}</div>}
              </div>
              {subtitle && (
                <p className="text-[13px] text-[#616161] font-[450] mt-0.5 leading-normal">
                  {subtitle}
                </p>
              )}
            </div>
          </div>

          {/* Right: Actions Cluster (Secondary on canvas + exactly one Primary) */}
          {(secondaryActions.length > 0 || primaryAction) && (
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {secondaryActions.map((action, idx) => (
                <button
                  key={idx}
                  onClick={action.onClick}
                  disabled={action.disabled}
                  className="h-7 px-3 rounded-lg bg-[#E3E3E3] hover:bg-[#D4D4D4] active:bg-[#C9C9C9] text-[#303030] text-[13px] font-[550] inline-flex items-center space-x-1.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-2xs"
                >
                  {action.icon && <span className="w-3.5 h-3.5">{action.icon}</span>}
                  <span>{action.label}</span>
                </button>
              ))}

              {primaryAction && (
                <button
                  onClick={primaryAction.onClick}
                  disabled={primaryAction.disabled}
                  className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] active:bg-black text-white text-[13px] font-[550] inline-flex items-center space-x-1.5 transition-colors border border-[#1A1A1A] shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {primaryAction.icon && <span className="w-3.5 h-3.5">{primaryAction.icon}</span>}
                  <span>{primaryAction.label}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Page Content Cards */}
        <div className="space-y-4">{children}</div>
      </div>
    </div>
  );
};
