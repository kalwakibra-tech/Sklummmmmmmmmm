import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import {
  LayoutDashboard,
  ClipboardList,
  Plane,
  Truck,
  FileText,
  Users,
  History,
  UserCheck,
  BarChart3,
  Settings,
  X,
} from 'lucide-react';

interface SidebarProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onNavigate,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const { state } = useApp();

  const draftsCount = state.drafts.length;

  const navItems: {
    id: ScreenName;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    activeScreenMatches?: ScreenName[];
  }[] = [
    {
      id: 'orders',
      label: 'Officer Orders',
      icon: ClipboardList,
      activeScreenMatches: ['new-officer-order', 'edit-officer-order'],
    },
    {
      id: 'airman-orders',
      label: 'Airman Orders',
      icon: Plane,
      activeScreenMatches: ['new-airman-order', 'edit-airman-order'],
    },
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'delivery',
      label: 'Delivery',
      icon: Truck,
    },
    {
      id: 'drafts',
      label: 'Drafts',
      icon: FileText,
      badge: draftsCount > 0 ? draftsCount : undefined,
    },
    {
      id: 'customers',
      label: 'Customers',
      icon: Users,
    },
    {
      id: 'customer-history',
      label: 'Customer History',
      icon: History,
    },
    {
      id: 'staff-management',
      label: 'Staff Management',
      icon: UserCheck,
      activeScreenMatches: ['worker-page'],
    },
    {
      id: 'staff-summary',
      label: 'Staff Summary',
      icon: BarChart3,
      activeScreenMatches: ['worker-history'],
    },
  ];

  const handleItemClick = (id: ScreenName) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  const isSelected = (item: typeof navItems[0]) => {
    if (currentScreen === item.id) return true;
    if (item.activeScreenMatches && item.activeScreenMatches.includes(currentScreen)) return true;
    return false;
  };

  const isSettingsActive = currentScreen === 'settings';

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between p-3 select-none">
      {/* Primary Flat Navigation Rail */}
      <div className="space-y-0.5">
        {navItems.map((item) => {
          const selected = isSelected(item);
          const IconComponent = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className={`w-full h-7 px-2 rounded-lg flex items-center justify-between text-[13px] transition-colors ${
                selected
                  ? 'bg-[#FAFAFA] font-[550] text-[#1A1A1A] shadow-2xs'
                  : 'text-[#303030] font-[450] hover:bg-black/5'
              }`}
              aria-current={selected ? 'page' : undefined}
            >
              <div className="flex items-center space-x-2 truncate">
                <IconComponent
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    selected ? 'text-[#000000] stroke-[2]' : 'text-[#3A3A3A] stroke-[1.6]'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[11px] font-semibold ${
                    selected
                      ? 'bg-[#1A1A1A] text-white'
                      : 'bg-[#DCDCDC] text-[#404040]'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Pinned Footer: Settings */}
      <div className="pt-3 border-t border-[#DCDCDC] mt-auto">
        <button
          onClick={() => handleItemClick('settings')}
          className={`w-full h-7 px-2 rounded-lg flex items-center space-x-2 text-[13px] transition-colors ${
            isSettingsActive
              ? 'bg-[#FAFAFA] font-[550] text-[#1A1A1A] shadow-2xs'
              : 'text-[#303030] font-[450] hover:bg-black/5'
          }`}
          aria-current={isSettingsActive ? 'page' : undefined}
        >
          <Settings
            className={`w-4 h-4 shrink-0 ${
              isSettingsActive ? 'text-[#000000] stroke-[2]' : 'text-[#3A3A3A] stroke-[1.6]'
            }`}
          />
          <span className="truncate">Settings</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar (240px wide, #EBEBEB) */}
      <aside
        className="hidden lg:block w-60 shrink-0 bg-[#EBEBEB] border-r border-[#E3E3E3] h-[calc(100vh-var(--topbar-h))] sticky top-14 overflow-y-auto"
        style={{ width: 'var(--sidebar-w)' }}
        aria-label="Main Navigation"
      >
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Navigation (< 1040px) */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex animate-in fade-in duration-150">
          {/* Backdrop Scrim */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-2xs"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />

          {/* Drawer Sheet */}
          <div className="relative w-64 max-w-[80vw] bg-[#EBEBEB] h-full shadow-2xl z-10 flex flex-col animate-in slide-in-from-left duration-200">
            <div className="h-14 px-4 flex items-center justify-between border-b border-[#DCDCDC] bg-[#1A1A1A] text-white">
              <span className="font-semibold text-sm">Navigation</span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 rounded-md text-gray-300 hover:text-white hover:bg-[#303030]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">{sidebarContent}</div>
          </div>
        </div>
      )}
    </>
  );
};
