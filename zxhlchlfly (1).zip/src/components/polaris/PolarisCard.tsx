import React from 'react';

export interface PolarisCardProps {
  title?: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  flush?: boolean;
  className?: string;
}

export const PolarisCard: React.FC<PolarisCardProps> = ({
  title,
  subtitle,
  actions,
  children,
  flush = false,
  className = '',
}) => {
  return (
    <div
      className={`bg-white rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)] overflow-hidden ${className}`}
      style={{ borderRadius: 'var(--radius-md)' }}
    >
      {(title || actions) && (
        <div className="px-4 py-3.5 border-b border-[#E3E3E3] flex items-center justify-between gap-3">
          <div>
            <h2 className="text-[14px] leading-5 font-[650] text-[#1A1A1A] m-0">
              {title}
            </h2>
            {subtitle && (
              <p className="text-[12px] text-[#616161] mt-0.5 font-[450]">{subtitle}</p>
            )}
          </div>
          {actions && <div className="shrink-0 flex items-center space-x-2">{actions}</div>}
        </div>
      )}

      <div className={flush ? '' : 'p-4'}>{children}</div>
    </div>
  );
};

export const PolarisCardSection: React.FC<{
  children: React.ReactNode;
  title?: string;
  inset?: boolean;
  className?: string;
}> = ({ children, title, inset = false, className = '' }) => {
  return (
    <div
      className={`p-4 border-t border-[#E3E3E3] first:border-t-0 ${
        inset ? 'bg-[#F7F7F7]' : 'bg-white'
      } ${className}`}
    >
      {title && (
        <h3 className="text-[13px] leading-5 font-[650] text-[#1A1A1A] mb-2">{title}</h3>
      )}
      {children}
    </div>
  );
};
