import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder, OrderStatus } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { formatDate } from '../utils/logic.ts';
import {
  Scissors,
  Truck,
  Plus,
  CreditCard,
  Printer,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Phone,
  Clock,
  ArrowRight,
  TrendingUp,
  X,
  Plane,
  ClipboardList,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { TailorShearsIllustration, EmptyBoxIllustration } from './Illustrations.tsx';

interface DashboardScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

function getDeliveryDiffDays(deliveryDateStr: string | undefined, today: string) {
  if (!deliveryDateStr) return null;
  const dDate = new Date(deliveryDateStr).getTime();
  const tDate = new Date(today).getTime();
  return Math.round((dDate - tDate) / (1000 * 3600 * 24));
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  const { state, updateOfficerOrderStatus, recordOfficerPayment } = useApp();

  const [activeQueueTab, setActiveQueueTab] = useState<'all' | 'cutting' | 'upcoming' | 'overdue'>('all');
  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<string>('');

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Active orders in pipeline (Not yet delivered)
  const activeOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  const activeAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const totalActivePipeline = activeOfficerOrders.length + activeAirmanOrders.length;

  // Cutting slips needed (Pending orders awaiting cutting slip)
  const cuttingSlipNeededOfficer = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Pending');
  }, [state.officerOrders]);

  // Overdue orders
  const overdueOrders = useMemo(() => {
    return state.officerOrders.filter((o) => {
      if (o.status === 'Delivered') return false;
      if (!o.deliveryDate) return false;
      const diff = getDeliveryDiffDays(o.deliveryDate, todayStr);
      return diff !== null && diff < 0;
    });
  }, [state.officerOrders, todayStr]);

  // Upcoming deliveries (Next 3 days)
  const upcomingDeliveries = useMemo(() => {
    return state.officerOrders
      .filter((o) => {
        if (o.status === 'Delivered') return false;
        const diff = getDeliveryDiffDays(o.deliveryDate, todayStr);
        return diff !== null && diff >= 0 && diff <= upcomingDays;
      })
      .sort((a, b) => (a.deliveryDate || '').localeCompare(b.deliveryDate || ''));
  }, [state.officerOrders, todayStr, upcomingDays]);

  // Total Outstanding Due across all orders
  const totalOutstandingDue = useMemo(() => {
    return state.officerOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
  }, [state.officerOrders]);

  const ordersWithDueCount = useMemo(() => {
    return state.officerOrders.filter((o) => (o.due || 0) > 0).length;
  }, [state.officerOrders]);

  // Priority Workshop Queue
  const priorityQueue = useMemo(() => {
    let list: OfficerOrder[] = [];

    if (activeQueueTab === 'cutting') {
      list = cuttingSlipNeededOfficer;
    } else if (activeQueueTab === 'upcoming') {
      list = upcomingDeliveries;
    } else if (activeQueueTab === 'overdue') {
      list = overdueOrders;
    } else {
      // 'all': Combine overdue first, then upcoming, then pending cutting slips
      const seen = new Set<number>();
      const combined: OfficerOrder[] = [];

      overdueOrders.forEach((o) => {
        if (!seen.has(o.orderNumber)) {
          seen.add(o.orderNumber);
          combined.push(o);
        }
      });

      upcomingDeliveries.forEach((o) => {
        if (!seen.has(o.orderNumber)) {
          seen.add(o.orderNumber);
          combined.push(o);
        }
      });

      cuttingSlipNeededOfficer.forEach((o) => {
        if (!seen.has(o.orderNumber)) {
          seen.add(o.orderNumber);
          combined.push(o);
        }
      });

      // Fallback to recent active orders if none urgent
      if (combined.length === 0) {
        list = activeOfficerOrders.slice(0, 5);
      } else {
        list = combined;
      }
    }

    return list.slice(0, 10);
  }, [activeQueueTab, cuttingSlipNeededOfficer, upcomingDeliveries, overdueOrders, activeOfficerOrders]);

  // Weekly collections calculation
  const weeklyCollections = useMemo(() => {
    const now = new Date();
    const currentDay = now.getDay();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - currentDay);
    startOfWeek.setHours(0, 0, 0, 0);

    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);

    let totalAdvances = 0;
    let totalPayments = 0;

    state.officerOrders.forEach((o) => {
      if (o.advance && o.orderDate) {
        const d = new Date(o.orderDate);
        if (d >= startOfWeek && d <= endOfWeek) {
          totalAdvances += Number(o.advance) || 0;
        }
      }
      (o.payments || []).forEach((p) => {
        if (p.date) {
          const d = new Date(p.date);
          if (d >= startOfWeek && d <= endOfWeek) {
            totalPayments += Number(p.amount) || 0;
          }
        }
      });
    });

    return {
      totalAdvances,
      totalPayments,
      grandTotal: totalAdvances + totalPayments,
    };
  }, [state.officerOrders]);

  // Recent workshop activity
  const recentActivities = useMemo(() => {
    const events: { id: string; title: string; subtitle: string; time: string; type: 'order' | 'delivery' | 'payment' }[] = [];

    // Delivered orders
    state.officerOrders
      .filter((o) => o.status === 'Delivered')
      .slice(0, 3)
      .forEach((o) => {
        events.push({
          id: `del-${o.id}`,
          title: `Order #${o.orderNumber} Delivered`,
          subtitle: `${o.customerName} · BD/${o.customerBdNumber}`,
          time: o.deliveryDate || o.orderDate,
          type: 'delivery',
        });
      });

    // Payments recorded
    state.officerOrders.forEach((o) => {
      (o.payments || []).slice(-2).forEach((p, idx) => {
        events.push({
          id: `pay-${o.id}-${idx}`,
          title: `Payment ৳${Number(p.amount).toLocaleString()}`,
          subtitle: `Order #${o.orderNumber} · ${o.customerName}`,
          time: p.date,
          type: 'payment',
        });
      });
    });

    // Recent orders
    state.officerOrders.slice(0, 3).forEach((o) => {
      events.push({
        id: `ord-${o.id}`,
        title: `Order #${o.orderNumber} Created`,
        subtitle: `${o.customerName} · ৳${Number(o.totalAmount).toLocaleString()}`,
        time: o.orderDate,
        type: 'order',
      });
    });

    return events.slice(0, 5);
  }, [state.officerOrders]);

  const handleOpenPay = (order: OfficerOrder) => {
    setPayTargetOrder(order);
    setPayAmountInput(String(order.due || ''));
  };

  const handleConfirmPay = () => {
    if (!payTargetOrder) return;
    const amountNum = parseFloat(payAmountInput);
    if (!amountNum || amountNum <= 0) return;

    recordOfficerPayment(payTargetOrder.orderNumber, amountNum);
    setPayTargetOrder(null);
  };

  return (
    <PolarisPage
      title="Workshop Dashboard"
      subtitle="Live uniform pipeline, cutting queue, and dispatch schedule"
      secondaryActions={[
        {
          label: 'Delivery Queue',
          onClick: () => onNavigate('delivery'),
          icon: <Truck className="w-3.5 h-3.5" />,
        },
        {
          label: 'Airman Orders',
          onClick: () => onNavigate('airman-orders'),
          icon: <Plane className="w-3.5 h-3.5" />,
        },
      ]}
      primaryAction={{
        label: 'New Officer Order',
        onClick: () => onNavigate('new-officer-order'),
        icon: <Plus className="w-3.5 h-3.5" />,
      }}
      fullWidth={true}
    >
      {/* 4-Column Polaris Operational Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Active Pipeline */}
        <div
          onClick={() => onNavigate('orders')}
          className="p-4 bg-white rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)] hover:border-[#8A8A8A] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-[450] text-[#616161]">Active Pipeline</span>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#EBEBEB] text-[#303030] font-medium">
              Officers & Airmen
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-[20px] leading-7 font-[650] text-[#1A1A1A] tabular-nums">
              {totalActivePipeline} <span className="text-[13px] font-normal text-[#616161]">orders</span>
            </div>
            <span className="text-[12px] text-[#005BD3] group-hover:underline font-medium">
              View all
            </span>
          </div>
        </div>

        {/* Metric 2: Cutting Slips Needed */}
        <div
          onClick={() => {
            onNavigate('orders');
          }}
          className={`p-4 bg-white rounded-xl border shadow-[0_1px_0_rgba(26,26,26,0.07)] hover:border-[#8A8A8A] transition-all cursor-pointer group ${
            cuttingSlipNeededOfficer.length > 0 ? 'border-amber-200 bg-[#FFFDF8]' : 'border-[#E3E3E3]'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-[450] text-[#616161]">Cutting Slips Needed</span>
            <span
              className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${
                cuttingSlipNeededOfficer.length > 0
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-[#EBEBEB] text-[#303030]'
              }`}
            >
              Pending Slip
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-[20px] leading-7 font-[650] text-[#1A1A1A] tabular-nums">
              {cuttingSlipNeededOfficer.length}{' '}
              <span className="text-[13px] font-normal text-[#616161]">to cut</span>
            </div>
            <span className="text-[12px] text-[#005BD3] group-hover:underline font-medium">
              Print queue
            </span>
          </div>
        </div>

        {/* Metric 3: Upcoming Deliveries */}
        <div
          onClick={() => onNavigate('delivery')}
          className={`p-4 bg-white rounded-xl border shadow-[0_1px_0_rgba(26,26,26,0.07)] hover:border-[#8A8A8A] transition-all cursor-pointer group ${
            overdueOrders.length > 0 ? 'border-[#FEE9E8] bg-[#FFF8F8]' : 'border-[#E3E3E3]'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-[450] text-[#616161]">Upcoming Deliveries</span>
            {overdueOrders.length > 0 ? (
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#FEE9E8] text-[#8E0B21] font-semibold">
                {overdueOrders.length} Overdue
              </span>
            ) : (
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#EBEBEB] text-[#303030] font-medium">
                Next {upcomingDays} days
              </span>
            )}
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-[20px] leading-7 font-[650] text-[#1A1A1A] tabular-nums">
              {upcomingDeliveries.length}{' '}
              <span className="text-[13px] font-normal text-[#616161]">orders</span>
            </div>
            <span className="text-[12px] text-[#005BD3] group-hover:underline font-medium">
              Dispatch
            </span>
          </div>
        </div>

        {/* Metric 4: Outstanding Receivables */}
        <div className="p-4 bg-white rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-[450] text-[#616161]">Total Receivables</span>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#EBEBEB] text-[#303030] font-medium">
              {ordersWithDueCount} orders with due
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-[20px] leading-7 font-[650] text-[#1A1A1A] tabular-nums font-mono">
              ৳{totalOutstandingDue.toLocaleString()}
            </div>
            <span className="text-[12px] text-[#616161]">Total balance</span>
          </div>
        </div>
      </div>

      {/* Main Section: Priority Workshop Queue */}
      <PolarisCard flush={true}>
        {/* Queue Header & Tabs */}
        <div className="p-4 border-b border-[#E3E3E3] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-[14px] font-[650] text-[#1A1A1A]">
              Workshop Priority Queue
            </h2>
            <p className="text-[12px] text-[#616161] mt-0.5">
              Orders requiring immediate cutting, delivery dispatch, or balance settlement
            </p>
          </div>

          {/* Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setActiveQueueTab('all')}
              className={`h-7 px-3 text-[12px] font-[550] rounded-lg transition-colors ${
                activeQueueTab === 'all'
                  ? 'bg-[#1A1A1A] text-white'
                  : 'bg-[#F1F1F1] text-[#616161] hover:text-[#1A1A1A]'
              }`}
            >
              All Priority
            </button>
            <button
              onClick={() => setActiveQueueTab('cutting')}
              className={`h-7 px-3 text-[12px] font-[550] rounded-lg transition-colors flex items-center space-x-1 ${
                activeQueueTab === 'cutting'
                  ? 'bg-[#1A1A1A] text-white'
                  : 'bg-[#F1F1F1] text-[#616161] hover:text-[#1A1A1A]'
              }`}
            >
              <Scissors className="w-3 h-3" />
              <span>Cutting Slips ({cuttingSlipNeededOfficer.length})</span>
            </button>
            <button
              onClick={() => setActiveQueueTab('upcoming')}
              className={`h-7 px-3 text-[12px] font-[550] rounded-lg transition-colors flex items-center space-x-1 ${
                activeQueueTab === 'upcoming'
                  ? 'bg-[#1A1A1A] text-white'
                  : 'bg-[#F1F1F1] text-[#616161] hover:text-[#1A1A1A]'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>Deliveries ({upcomingDeliveries.length})</span>
            </button>
            {overdueOrders.length > 0 && (
              <button
                onClick={() => setActiveQueueTab('overdue')}
                className={`h-7 px-3 text-[12px] font-[550] rounded-lg transition-colors flex items-center space-x-1 ${
                  activeQueueTab === 'overdue'
                    ? 'bg-[#8E0B21] text-white'
                    : 'bg-[#FEE9E8] text-[#8E0B21] hover:bg-[#FCD2D0]'
                }`}
              >
                <AlertCircle className="w-3 h-3" />
                <span>Overdue ({overdueOrders.length})</span>
              </button>
            )}
          </div>
        </div>

        {/* Priority Orders List (Desktop Table + Mobile Cards) */}
        {priorityQueue.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <TailorShearsIllustration className="w-16 h-16 mx-auto mb-3 text-[#616161]" />
            <h3 className="text-[14px] font-[650] text-[#1A1A1A]">Workshop Queue Clear</h3>
            <p className="text-[13px] text-[#616161] max-w-sm mx-auto mt-1">
              All active orders are on schedule. No urgent cutting slips or overdue deliveries at this moment.
            </p>
            <button
              onClick={() => onNavigate('new-officer-order')}
              className="mt-4 h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550] inline-flex items-center space-x-1.5 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Order</span>
            </button>
          </div>
        ) : (
          <div>
            {/* Desktop View (Table: >= 768px) */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="h-9 border-b border-[#E3E3E3] bg-[#FAFAFA] text-[13px] font-[450] text-[#616161]">
                    <th className="px-4 w-20 text-left">Order</th>
                    <th className="px-4 text-left">Officer / Customer</th>
                    <th className="px-4 text-left">Uniform Items</th>
                    <th className="px-4 text-left">Delivery Date</th>
                    <th className="px-4 text-right">Balance Due</th>
                    <th className="px-4 text-center w-36">Status</th>
                    <th className="px-4 text-right w-40">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3E3] text-[13px]">
                  {priorityQueue.map((order) => {
                    const diffDays = getDeliveryDiffDays(order.deliveryDate, todayStr);
                    const isOverdue = order.status !== 'Delivered' && diffDays !== null && diffDays < 0;
                    const isSoon = order.status !== 'Delivered' && diffDays !== null && diffDays >= 0 && diffDays <= upcomingDays;
                    const hasDue = (order.due || 0) > 0;

                    return (
                      <tr
                        key={order.id}
                        onClick={() =>
                          onNavigate('order-details', {
                            orderNumber: order.orderNumber,
                            category: 'Officer',
                          })
                        }
                        className="h-[54px] hover:bg-[#F7F7F7] cursor-pointer transition-colors"
                      >
                        <td className="px-4 font-[650] text-[#1A1A1A]">#{order.orderNumber}</td>
                        <td className="px-4">
                          <div className="font-[550] text-[#1A1A1A] line-clamp-1">
                            {order.customerName}
                          </div>
                          <div className="text-[11px] text-[#616161] font-mono">
                            BD/{order.customerBdNumber}
                            {order.branch && <span> · {order.branch}</span>}
                          </div>
                        </td>
                        <td className="px-4 text-[#616161] max-w-[200px]">
                          <span className="line-clamp-1">
                            {order.items.map((i) => `${i.name} ×${i.quantity}`).join(', ')}
                          </span>
                        </td>
                        <td className="px-4 text-[12px]">
                          <div className="flex items-center space-x-1.5">
                            <span className="font-mono text-[#303030]">{order.deliveryDate || '—'}</span>
                            {isOverdue && (
                              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-[#FEE9E8] text-[#8E0B21]">
                                Overdue
                              </span>
                            )}
                            {isSoon && (
                              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-[#FEF3C7] text-[#92400E]">
                                {diffDays === 0 ? 'Today' : `${diffDays}d`}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 text-right font-[650] tabular-nums font-mono">
                          {hasDue ? (
                            <span className="text-[#8E0B21]">৳{order.due.toLocaleString()}</span>
                          ) : (
                            <span className="text-[#0C5132] font-normal">Paid</span>
                          )}
                        </td>
                        <td className="px-4 text-center" onClick={(e) => e.stopPropagation()}>
                          <StatusBadge
                            status={order.status}
                            interactive={true}
                            onChange={(newStatus) =>
                              updateOfficerOrderStatus(order.orderNumber, newStatus)
                            }
                          />
                        </td>
                        <td className="px-4 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end space-x-1">
                            <button
                              onClick={() =>
                                onNavigate('print-slip', {
                                  orderNumber: order.orderNumber,
                                  category: 'Officer',
                                })
                              }
                              title="Print Cutting Slip"
                              className="p-1.5 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded-lg transition-colors"
                            >
                              <Scissors className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() =>
                                onNavigate('print-invoice', {
                                  orderNumber: order.orderNumber,
                                  category: 'Officer',
                                })
                              }
                              title="Print Invoice"
                              className="p-1.5 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded-lg transition-colors"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            {hasDue && (
                              <button
                                onClick={() => handleOpenPay(order)}
                                title="Record Payment"
                                className="h-6 px-2 rounded-md bg-[#303030] hover:bg-[#1A1A1A] text-white text-[11px] font-[550] inline-flex items-center space-x-1 transition-colors"
                              >
                                <CreditCard className="w-3 h-3" />
                                <span>Pay</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile View (Cards: < 768px) */}
            <div className="md:hidden divide-y divide-[#E3E3E3]">
              {priorityQueue.map((order) => {
                const diffDays = getDeliveryDiffDays(order.deliveryDate, todayStr);
                const isOverdue = order.status !== 'Delivered' && diffDays !== null && diffDays < 0;
                const isSoon = order.status !== 'Delivered' && diffDays !== null && diffDays >= 0 && diffDays <= upcomingDays;
                const hasDue = (order.due || 0) > 0;

                return (
                  <div
                    key={order.id}
                    onClick={() =>
                      onNavigate('order-details', {
                        orderNumber: order.orderNumber,
                        category: 'Officer',
                      })
                    }
                    className="p-4 hover:bg-[#FAFAFA] active:bg-[#F5F5F5] transition-colors"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-[650] text-[#1A1A1A] text-[14px]">
                            #{order.orderNumber}
                          </span>
                          <span className="text-[12px] font-mono text-[#616161]">
                            BD/{order.customerBdNumber}
                          </span>
                        </div>
                        <h4 className="font-[600] text-[14px] text-[#1A1A1A] mt-0.5">
                          {order.customerName}
                        </h4>
                      </div>
                      <StatusBadge
                        status={order.status}
                        interactive={true}
                        onChange={(newStatus) =>
                          updateOfficerOrderStatus(order.orderNumber, newStatus)
                        }
                      />
                    </div>

                    <p className="text-[12px] text-[#616161] mt-2 line-clamp-1">
                      {order.items.map((i) => `${i.name} ×${i.quantity}`).join(', ')}
                    </p>

                    <div className="mt-3 pt-2.5 border-t border-[#F0F0F0] flex items-center justify-between text-[12px]">
                      <div>
                        <span className="text-[#8A8A8A] block text-[10px]">Delivery:</span>
                        <div className="flex items-center space-x-1.5 font-mono">
                          <span className="font-medium text-[#303030]">
                            {order.deliveryDate || '—'}
                          </span>
                          {isOverdue && (
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-[#FEE9E8] text-[#8E0B21]">
                              Overdue
                            </span>
                          )}
                          {isSoon && (
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-[#FEF3C7] text-[#92400E]">
                              {diffDays === 0 ? 'Today' : `${diffDays}d`}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[#8A8A8A] block text-[10px]">Due Balance:</span>
                        <span
                          className={`font-[650] font-mono tabular-nums ${
                            hasDue ? 'text-[#8E0B21]' : 'text-[#0C5132]'
                          }`}
                        >
                          ৳{order.due.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Mobile Action Buttons */}
                    <div
                      className="mt-3 flex items-center justify-end space-x-2 pt-2 border-t border-[#F5F5F5]"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        onClick={() =>
                          onNavigate('print-slip', {
                            orderNumber: order.orderNumber,
                            category: 'Officer',
                          })
                        }
                        className="h-8 px-2.5 rounded-lg bg-[#E3E3E3] hover:bg-[#D4D4D4] text-[#303030] text-[12px] font-medium flex items-center space-x-1"
                      >
                        <Scissors className="w-3.5 h-3.5" />
                        <span>Cutting Slip</span>
                      </button>
                      {hasDue && (
                        <button
                          onClick={() => handleOpenPay(order)}
                          className="h-8 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[12px] font-medium flex items-center space-x-1"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                          <span>Pay ৳{order.due.toLocaleString()}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </PolarisCard>

      {/* 2-Column Split: Weekly Collections & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Weekly Workshop Collections */}
        <PolarisCard flush={false}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[14px] font-[650] text-[#1A1A1A]">Weekly Workshop Collections</h3>
            <span className="text-[11px] font-medium text-[#616161]">Current Week</span>
          </div>

          <div className="p-4 bg-[#FAFAFA] rounded-xl border border-[#E3E3E3] mb-4">
            <div className="text-[12px] text-[#616161]">Total Collected This Week</div>
            <div className="text-[24px] font-[700] text-[#1A1A1A] font-mono mt-1">
              ৳{weeklyCollections.grandTotal.toLocaleString()}
            </div>
            <div className="flex items-center space-x-4 text-[12px] text-[#616161] mt-2 pt-2 border-t border-[#EBEBEB]">
              <span>Advances: ৳{weeklyCollections.totalAdvances.toLocaleString()}</span>
              <span>·</span>
              <span>Delivery Payments: ৳{weeklyCollections.totalPayments.toLocaleString()}</span>
            </div>
          </div>

          <p className="text-[12px] text-[#616161] leading-relaxed">
            All cash advances and balance collections are logged against each customer profile and worker hishab.
          </p>
        </PolarisCard>

        {/* Recent Workshop Activity */}
        <PolarisCard flush={false}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[14px] font-[650] text-[#1A1A1A]">Recent Activity</h3>
            <span className="text-[11px] font-medium text-[#616161]">Latest log</span>
          </div>

          <div className="space-y-3">
            {recentActivities.map((act) => (
              <div key={act.id} className="flex items-start space-x-3 text-[13px]">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                    act.type === 'delivery'
                      ? 'bg-[#AFFEBF] text-[#0C5132]'
                      : act.type === 'payment'
                      ? 'bg-[#C4E4F9] text-[#00527C]'
                      : 'bg-[#E3E3E3] text-[#303030]'
                  }`}
                >
                  {act.type === 'delivery' ? (
                    <Truck className="w-3.5 h-3.5" />
                  ) : act.type === 'payment' ? (
                    <CreditCard className="w-3.5 h-3.5" />
                  ) : (
                    <ClipboardList className="w-3.5 h-3.5" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-[550] text-[#1A1A1A] truncate">{act.title}</div>
                  <div className="text-[11px] text-[#616161] truncate">{act.subtitle}</div>
                </div>
                <div className="text-[11px] text-[#8A8A8A] font-mono shrink-0">{act.time}</div>
              </div>
            ))}
          </div>
        </PolarisCard>
      </div>

      {/* Payment Recording Modal */}
      {payTargetOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-[#E3E3E3]">
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">
                Record Payment — Order #{payTargetOrder.orderNumber}
              </h3>
              <button
                onClick={() => setPayTargetOrder(null)}
                className="p-1 rounded-md text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <span className="text-[12px] text-[#616161] block">Customer</span>
                <span className="font-[600] text-[14px] text-[#1A1A1A]">
                  {payTargetOrder.customerName} (BD/{payTargetOrder.customerBdNumber})
                </span>
              </div>
              <div className="p-3 bg-[#FAFAFA] border border-[#E3E3E3] rounded-lg">
                <div className="text-[12px] text-[#616161]">Outstanding Due</div>
                <div className="text-[20px] font-[650] text-[#8E0B21] font-mono mt-0.5">
                  ৳{payTargetOrder.due.toLocaleString()}
                </div>
              </div>
              <div>
                <label className="text-[12px] font-medium text-[#303030] block mb-1">
                  Payment Amount (৳)
                </label>
                <input
                  type="number"
                  value={payAmountInput}
                  onChange={(e) => setPayAmountInput(e.target.value)}
                  className="w-full h-9 px-3 border border-[#8A8A8A] rounded-lg text-sm text-[#303030] focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
                  placeholder="Enter amount"
                />
              </div>
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setPayTargetOrder(null)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] hover:bg-[#F3F3F3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmPay}
                className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
              >
                Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
