import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Draft } from '../types/index.ts';
import { ConfirmModal } from './ConfirmModal.tsx';
import { FileText, Trash2, ArrowLeft, Clock, ArrowRight, User, Phone, Sparkles } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';

interface DraftsScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DraftsScreen: React.FC<DraftsScreenProps> = ({ onNavigate }) => {
  const { state, deleteDraft } = useApp();
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  const formatRelativeTime = (isoString: string) => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 1) return 'Saved just now';
      if (diffMins < 60) return `Saved ${diffMins}m ago`;
      if (diffHours < 24) return `Saved ${diffHours}h ago`;
      return `Saved ${diffDays}d ago`;
    } catch {
      return 'Saved recently';
    }
  };

  const sortedDrafts = [...state.drafts].sort((a, b) => {
    return new Date(b.lastSaved).getTime() - new Date(a.lastSaved).getTime();
  });

  const handleDeleteConfirm = () => {
    if (deleteTargetId) {
      deleteDraft(deleteTargetId);
      setDeleteTargetId(null);
    }
  };

  const handleOpenDraft = (draft: Draft) => {
    if (draft.category === 'Officer') {
      onNavigate('new-officer-order', { draftId: draft.id });
    } else {
      onNavigate('new-airman-order', { draftId: draft.id });
    }
  };

  return (
    <PolarisPage
      title="Saved Drafts"
      subtitle="Unfinished orders stored across sessions for easy completion"
      badge={
        <PolarisBadge tone="neutral">
          {sortedDrafts.length} {sortedDrafts.length === 1 ? 'draft' : 'drafts'}
        </PolarisBadge>
      }
      backAction={() => onNavigate('orders')}
    >
      {/* Delete Draft Modal */}
      <ConfirmModal
        isOpen={!!deleteTargetId}
        title="Delete this draft?"
        message="This unfinished order will be permanently deleted and cannot be recovered."
        confirmLabel="Delete Draft"
        cancelLabel="Cancel"
        confirmVariant="danger"
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTargetId(null)}
      />

      {sortedDrafts.length > 0 ? (
        <PolarisCard flush>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-[#E3E3E3] bg-[#FAFBFB] text-[#616161] font-semibold h-[37px]">
                  <th className="px-4 py-2 w-28">Category</th>
                  <th className="px-4 py-2 w-32">BD Number</th>
                  <th className="px-4 py-2">Customer Name</th>
                  <th className="px-4 py-2">Items Summary</th>
                  <th className="px-4 py-2 w-32">Last Saved</th>
                  <th className="px-4 py-2 text-right w-40">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3E3E3]">
                {sortedDrafts.map((draft) => {
                  const isOfficer = draft.category === 'Officer';
                  const items = isOfficer ? draft.officerItems || [] : draft.airmanItems || [];
                  const itemsSummary =
                    items.map((i: any) => `${i.name} ×${i.quantity}`).join(', ') || 'No items selected';

                  return (
                    <tr
                      key={draft.id}
                      className="h-[54px] hover:bg-[#F9FAFB] transition-colors cursor-pointer group"
                      onClick={() => handleOpenDraft(draft)}
                    >
                      <td className="px-4 py-2">
                        <PolarisBadge tone={isOfficer ? 'info' : 'warning'}>
                          {draft.category}
                        </PolarisBadge>
                      </td>
                      <td className="px-4 py-2 font-mono font-medium text-[#005BD3]">
                        {draft.customerBdNumber || '—'}
                      </td>
                      <td className="px-4 py-2">
                        <div className="font-semibold text-[#1A1A1A]">
                          {draft.customerName || 'Unnamed customer'}
                        </div>
                        {draft.customerPhone && (
                          <div className="text-[11px] text-[#616161]">
                            {draft.customerPhone}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-2 text-[#4A4A4A] truncate max-w-xs">
                        {itemsSummary}
                      </td>
                      <td className="px-4 py-2 text-[#616161] whitespace-nowrap">
                        <div className="flex items-center space-x-1.5">
                          <Clock className="w-3 h-3 text-[#616161]" />
                          <span>{formatRelativeTime(draft.lastSaved)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2 text-right">
                        <div
                          className="flex items-center justify-end space-x-2"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            onClick={() => handleOpenDraft(draft)}
                            className="inline-flex items-center space-x-1 px-3 py-1.5 bg-[#303030] hover:bg-[#1A1A1A] text-white text-xs font-semibold rounded-md shadow-xs transition-colors"
                          >
                            <span>Resume</span>
                            <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTargetId(draft.id)}
                            className="p-1.5 text-[#616161] hover:text-[#8E0B21] hover:bg-[#FBEAE5] rounded-md transition-colors"
                            title="Delete draft"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </PolarisCard>
      ) : (
        <PolarisCard>
          <div className="py-16 text-center text-[#616161] text-xs">
            <FileText className="w-8 h-8 mx-auto mb-2 text-[#616161] opacity-50" />
            <p className="font-semibold text-[#1A1A1A] text-sm">No saved drafts</p>
            <p className="mt-1 max-w-sm mx-auto">
              When creating orders, click &quot;Save as Draft&quot; to keep unfinished work safe and accessible here.
            </p>
          </div>
        </PolarisCard>
      )}
    </PolarisPage>
  );
};
